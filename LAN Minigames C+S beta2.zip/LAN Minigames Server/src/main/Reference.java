package main;

public class Reference {
	public static final String NAME = "LAN Minigames Server";
	public static final String VERSION = "dev_build";
	public static final String TITLE = NAME + " " + VERSION + " - ";
	public static final int SOCKET_1 = 7177;
	public static final int SOCKET_2 = 7178;
}