package games.solo;

public class Clicker {

}
