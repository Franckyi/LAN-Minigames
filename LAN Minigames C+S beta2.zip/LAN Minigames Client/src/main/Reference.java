package main;

public class Reference {
	public static final String NAME = "LAN Minigames Client";
	public static final String VERSION = "Beta 1.0";
	public static final String TITLE = NAME + " " + VERSION + " - ";
	public static final int SOCKET = 7177;
}
